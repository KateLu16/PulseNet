"""
PulseNet BLE Gateway (multi-device).

One Raspberry Pi bridges MANY student devices (ESP32) to the
FastAPI backend:

    ESP32 #1 ─┐
    ESP32 #2 ─┼─ BLE links ─> this gateway ─> HTTP ─> FastAPI
    ESP32 #N ─┘

Self-paced model:
    - The gateway follows ONE active quiz on the backend.
    - QUIZ_INFO is broadcast to every connected device.
    - Q1 is pushed to each device when the quiz starts.
    - After a device's answer is accepted, the NEXT question
      is pushed to THAT device only (each student advances
      at their own pace under the same quiz clock).
    - Quiz end (teacher or time limit) broadcasts QUIZ_END.

Reliability:
    - Devices are discovered by the PulseNet service UUID
      (plus any addresses in PULSENET_DEVICE_ADDRESSES).
    - Each device has its own connection task that reconnects
      automatically after a BLE drop.
    - On reconnect mid-quiz the gateway re-pushes the right
      question for that device's student.
    - The device stamps answers with a rising `sequence`
      counter; the backend keeps the newest attempt and
      ignores stale/duplicate deliveries.
"""

import asyncio
import json
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

from bleak import BleakClient, BleakScanner


# ============================================================
# CONFIGURATION
# ============================================================

# Comma-separated BLE addresses to always try in addition to
# scanning (useful when a device does not advertise the
# service UUID). Example:
#
#     PULSENET_DEVICE_ADDRESSES="54:43:B2:DC:B0:B2, ..."
#
DEVICE_ADDRESS = "54:43:B2:DC:B0:B2"

FASTAPI_URL = os.environ.get("PULSENET_API_URL", "http://127.0.0.1:8000")

# Whole-quiz countdown (seconds) used when the teacher has
# not set a custom time limit on the dashboard.
QUIZ_DEFAULT_TIME_LIMIT_SEC = 300

# How often the gateway re-reads quiz state from the backend.
QUIZ_POLL_INTERVAL = 1.5

SCAN_INTERVAL = 5.0
SCAN_TIMEOUT = 3.0
BLE_CONNECT_TIMEOUT = 8.0
RECONNECT_DELAY = 3.0
HEARTBEAT_INTERVAL = 2.0

INTERACTIVE = sys.stdin.isatty()


# ============================================================
# BLE UUID
# ============================================================

PULSENET_SERVICE_UUID = (
    "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
)

REGISTRATION_CHAR_UUID = (
    "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"
)

QUESTION_CHAR_UUID = (
    "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"
)

ANSWER_CHAR_UUID = (
    "6E400004-B5A3-F393-E0A9-E50E24DCCA9E"
)

ACK_CHAR_UUID = (
    "6E400005-B5A3-F393-E0A9-E50E24DCCA9E"
)


# ============================================================
# DEVICE LINK REGISTRY
# ============================================================

class DeviceLink:
    """
    One student device (by BLE address).

    `task`      : the running connection session (None while
                  disconnected / waiting to reconnect).
    `connected` : BLE link up.
    `student_id`: student registered from this device during
                  the active quiz (None until REGISTER).
    `last_pushed`: last question number pushed to this device
                  (None = nothing pushed for this quiz yet).
    """

    def __init__(self, address):
        self.address = address.upper()
        self.task = None
        self.client = None
        self.connected = False
        self.student_id = None
        self.last_pushed = None

    def status(self):
        return {
            "address": self.address,
            "connected": self.connected,
            "student_id": self.student_id,
            "last_pushed_question": self.last_pushed,
        }


# address (upper) -> DeviceLink
links: dict[str, DeviceLink] = {}

# BlueZ (the Pi's BLE stack) rejects a discovery request while
# another discovery/connect is starting up
# ("org.bluez.Error.InProgress"). The supervisor's scan and
# the per-device connects must therefore take turns starting;
# an ESTABLISHED connection does not block the scanner.
ble_lock = asyncio.Lock()


def get_or_create_link(address):
    address = str(address).strip().upper()
    link = links.get(address)
    if link is None:
        link = DeviceLink(address)
        links[address] = link
    return link


# Seed with the classic single device so the gateway keeps
# working before the first scan completes.
get_or_create_link(DEVICE_ADDRESS)

for extra in os.environ.get(
    "PULSENET_DEVICE_ADDRESSES", "",
).split(","):
    extra = extra.strip().upper()
    if extra:
        get_or_create_link(extra)


def connected_links():
    return [link for link in links.values() if link.connected]


# ============================================================
# ACTIVE QUIZ STATE
# ============================================================

ACTIVE_QUIZ_ID = None
ACTIVE_SESSION_ID = None

ACTIVE_QUIZ_TITLE = ""
ACTIVE_QUIZ_STATUS = ""
ACTIVE_QUIZ_TIME_LIMIT = 300
ACTIVE_QUIZ_EXPECTED = 0
ACTIVE_QUIZ_PREFIX = ""
ACTIVE_QUIZ_ID_LENGTH = 0

# (quiz_id, status, time_limit, total) of the last QUIZ_INFO
# packet broadcast, so it is only resent when changed.
QUIZ_SENT_INFO_KEY = None

# Quiz id for which QUIZ_END has already been broadcast.
QUIZ_END_SENT_QUIZ = None

# Question list cache per quiz (for self-paced advancing).
QUIZ_QUESTIONS = []
QUIZ_QUESTIONS_QUIZ_ID = None


# ============================================================
# RUNTIME REGISTRATION DATA
#
# student_id -> {
#     "device_mac": "...",
#     "device_name": "...",
#     "quiz_id": 1,
#     "link": DeviceLink,
# }
# ============================================================

registered_devices = {}


# ============================================================
# HELPERS - HTTP JSON
# ============================================================

def http_get_json(url, log=True):
    """HTTP GET -> (success, parsed JSON or None)."""
    request = urllib.request.Request(
        url,
        headers={"Accept": "application/json"},
        method="GET",
    )

    try:
        with urllib.request.urlopen(request, timeout=5) as response:
            body = response.read().decode("utf-8")

            if log:
                print(f"[HTTP GET] {url} -> {response.status}")

            if not (200 <= response.status < 300):
                return False, None

            try:
                return True, json.loads(body)
            except json.JSONDecodeError as e:
                print(f"[ERROR] Invalid JSON response: {e}")
                return False, None

    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        print(f"[ERROR] HTTP GET failed: {e.code} {body}")

        try:
            return False, json.loads(body)
        except json.JSONDecodeError:
            return False, None

    except Exception as e:
        print(f"[ERROR] HTTP GET failed: {type(e).__name__}: {e}")
        return False, None


def http_post_json(url, payload, log=True):
    """HTTP POST JSON -> (success, parsed JSON or None)."""
    data = json.dumps(payload).encode("utf-8")

    request = urllib.request.Request(
        url,
        data=data,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )

    if log:
        print(f"[HTTP POST] {url} {json.dumps(payload)}")

    try:
        with urllib.request.urlopen(request, timeout=5) as response:
            body = response.read().decode("utf-8")

            if log:
                print(f"[HTTP] {response.status} {body}")

            if not (200 <= response.status < 300):
                return False, None

            try:
                return True, json.loads(body)
            except json.JSONDecodeError:
                return False, None

    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        print(f"[ERROR] HTTP error: {e.code} {body}")

        try:
            return False, json.loads(body)
        except json.JSONDecodeError:
            return False, None

    except Exception as e:
        print(f"[ERROR] HTTP POST failed: {type(e).__name__}: {e}")
        return False, None


def http_get_json_quiet(url):
    try:
        with urllib.request.urlopen(url, timeout=5) as response:
            body = response.read().decode("utf-8")
            if not (200 <= response.status < 300):
                return False, None
            return True, json.loads(body)
    except Exception:
        return False, None


def http_post_json_quiet(url, payload):
    data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=5) as response:
            body = response.read().decode("utf-8")
            if not (200 <= response.status < 300):
                return False, None
            return True, json.loads(body)
    except Exception:
        return False, None


def normalize_mac(device_mac):
    return str(device_mac).strip().upper()


def device_code_from_mac(device_mac):
    """
    Display code derived from the BLE address, e.g.
    "1C:69:20:96:84:2A" -> "PULSENET-842A".

    Every board flashed with identical firmware reports the
    SAME device_name in its REGISTER packet, but the backend
    requires device_code to be UNIQUE per device — the MAC
    suffix is the stable unique part, so it becomes the code.
    """
    suffix = (
        normalize_mac(device_mac).replace(":", "")[-4:]
    )
    return f"PULSENET-{suffix}"


# ============================================================
# QUIZ DISCOVERY
# Teacher Web -> FastAPI -> Gateway
# ============================================================

def get_running_quiz():
    """
    Pick the quiz this gateway should follow.

    Priority: the followed quiz while it is still
    lobby/running, then the single running quiz, then the
    newest lobby, then the newest draft.
    """

    success, result = http_get_json(f"{FASTAPI_URL}/api/quizzes")

    if not success or not isinstance(result, list):
        print("[ERROR] Cannot get quizzes from FastAPI.")
        return None

    # 1. Keep following the quiz we last announced.

    if ACTIVE_QUIZ_ID is not None:
        for quiz in result:
            if (
                quiz.get("id") == ACTIVE_QUIZ_ID
                and quiz.get("status") in ("lobby", "running")
            ):
                return quiz

    running = [
        quiz for quiz in result
        if quiz.get("status") == "running"
    ]

    if not running:
        lobbies = [
            quiz for quiz in result
            if quiz.get("status") == "lobby"
        ]

        if lobbies:
            lobbies.sort(key=lambda q: q.get("id") or 0, reverse=True)
            print(
                f"[INFO] No running quiz. "
                f"Using newest lobby quiz {lobbies[0].get('id')}."
            )
            return lobbies[0]

        drafts = [
            quiz for quiz in result
            if quiz.get("status") == "draft"
        ]

        if drafts:
            drafts.sort(key=lambda q: q.get("id") or 0, reverse=True)
            print(
                f"[INFO] No running quiz. "
                f"Using newest draft quiz {drafts[0].get('id')}."
            )
            return drafts[0]

        return None

    if len(running) > 1:
        print("[ERROR] Multiple running quizzes — following the newest.")
        running.sort(key=lambda q: q.get("id") or 0, reverse=True)

    return running[0]


def refresh_active_quiz():
    """Discover and store the currently followed quiz."""
    global ACTIVE_QUIZ_ID
    global ACTIVE_SESSION_ID

    quiz = get_running_quiz()

    if quiz is None:
        ACTIVE_QUIZ_ID = None
        ACTIVE_SESSION_ID = None
        return False

    ACTIVE_QUIZ_ID = quiz.get("id")
    ACTIVE_SESSION_ID = f"QUIZ-{ACTIVE_QUIZ_ID}"

    print(
        f"[ACTIVE QUIZ] {ACTIVE_QUIZ_ID} "
        f"'{quiz.get('title')}' ({quiz.get('status')})"
    )

    return True


# ============================================================
# BLE CHARACTERISTIC
# ============================================================

def get_characteristic(client, uuid):
    if not client.is_connected:
        raise RuntimeError("BLE client is not connected.")

    services = client.services

    if services is None:
        raise RuntimeError("BLE services are not available.")

    characteristic = services.get_characteristic(uuid)

    if characteristic is None:
        raise RuntimeError(f"Characteristic not found: {uuid}")

    return characteristic


async def write_json(client, uuid, packet):
    data = json.dumps(packet, separators=(",", ":")).encode("utf-8")

    char = get_characteristic(client, uuid)

    await client.write_gatt_char(char, data, response=True)


# ============================================================
# SEND ACK PACKETS (Pi -> ESP32)
# ============================================================

async def send_register_ack(link, student_id, status, reason=None):
    packet = {
        "type": "REGISTER_ACK",
        "session_id": ACTIVE_SESSION_ID,
        "quiz_id": ACTIVE_QUIZ_ID,
        "student_id": student_id,
        "status": status,
    }

    if reason:
        packet["reason"] = reason

    await write_json(link.client, ACK_CHAR_UUID, packet)


async def send_answer_ack(
    link,
    question_id,
    status,
    reason=None,
    correct=None,
):
    packet = {
        "type": "ANSWER_ACK",
        "session_id": ACTIVE_SESSION_ID,
        "quiz_id": ACTIVE_QUIZ_ID,
        "question_id": question_id,
        "status": status,
    }

    if correct is not None:
        packet["correct"] = correct

    if reason:
        packet["reason"] = reason

    await write_json(link.client, ACK_CHAR_UUID, packet)


# ============================================================
# REGISTER DEVICE WITH FASTAPI
# ============================================================

def register_device_with_fastapi(
    student_id,
    device_mac,
    device_name,
    quiz_id,
):
    payload = {
        "student_id": student_id,
        "device_mac": normalize_mac(device_mac),

        # Not the firmware's device_name: all boards flashed
        # with the same code report an identical name, and the
        # backend needs this unique per device.
        "device_code": device_code_from_mac(device_mac),

        "quiz_id": quiz_id,
    }

    success, result = http_post_json(
        f"{FASTAPI_URL}/api/devices/register",
        payload,
    )

    if not success or not isinstance(result, dict):
        return False, result

    if result.get("success") is not True:
        print(
            "[ERROR] FastAPI rejected device registration: "
            f"{result.get('message', result.get('detail', 'unknown'))}"
        )
        return False, result

    print(f"[OK] {student_id} registered on {device_mac} (quiz {quiz_id}).")

    return True, result


# ============================================================
# SUBMIT ANSWER TO FASTAPI
# ============================================================

def submit_answer_to_fastapi(
    student_id,
    device_mac,
    question_id,
    answer,
    quiz_id,
    sequence=None,
):
    payload = {
        "student_id": student_id,
        "device_mac": normalize_mac(device_mac),
        "quiz_id": quiz_id,
        "question_id": question_id,
        "answer": answer,
    }

    if sequence is not None:
        payload["sequence"] = sequence

    success, result = http_post_json(
        f"{FASTAPI_URL}/api/responses/answer",
        payload,
    )

    if not success or not isinstance(result, dict):
        return False, result

    if result.get("success") is not True:
        return False, result

    print(
        f"[OK] Answer accepted ({result.get('status')}): "
        f"{'CORRECT' if result.get('correct') else 'WRONG'}"
    )

    return True, result


# ============================================================
# RELOAD REGISTRATIONS FROM BACKEND
#
# registered_devices is in-memory and lost on gateway
# restart; the DATABASE is the source of truth.
# ============================================================

def reload_registered_devices_from_backend(quiz_id):
    success, result = http_get_json(
        f"{FASTAPI_URL}/api/quizzes/{quiz_id}/students",
        log=False,
    )

    if not success or not isinstance(result, dict):
        return False

    students = result.get("students")

    if not isinstance(students, list):
        return False

    restored = 0

    for student in students:
        student_id = str(student.get("student_id", "") or "").strip()
        device_mac = normalize_mac(student.get("device_mac", "") or "")

        if not student_id:
            continue

        registered_devices[student_id] = {
            "device_mac": device_mac,
            "device_name": str(student.get("device_code", "") or ""),
            "quiz_id": quiz_id,
            "link": links.get(device_mac),
        }

        link = links.get(device_mac)

        if link is not None:
            link.student_id = student_id

        restored += 1

    if restored:
        print(
            f"[REG] Restored {restored} registration(s) "
            f"for quiz {quiz_id} from backend."
        )

    return restored > 0


# ============================================================
# QUESTION CACHE + PUSH (self-paced)
# ============================================================

async def ensure_questions_cache():
    """
    Load the quiz's question list once per quiz. An EMPTY
    cache is re-fetched every call (questions may have been
    imported after the first load).
    """
    global QUIZ_QUESTIONS
    global QUIZ_QUESTIONS_QUIZ_ID

    if ACTIVE_QUIZ_ID is None:
        return False

    if (
        QUIZ_QUESTIONS_QUIZ_ID == ACTIVE_QUIZ_ID
        and QUIZ_QUESTIONS
    ):
        return True

    success, questions = await asyncio.to_thread(
        http_get_json_quiet,
        f"{FASTAPI_URL}/api/quizzes/{ACTIVE_QUIZ_ID}/questions",
    )

    if not success or not isinstance(questions, list):
        return False

    previous_count = len(QUIZ_QUESTIONS)

    QUIZ_QUESTIONS = sorted(
        questions,
        key=lambda q: q.get("question_number") or 0,
    )

    QUIZ_QUESTIONS_QUIZ_ID = ACTIVE_QUIZ_ID

    if len(QUIZ_QUESTIONS) != previous_count:
        print(
            f"[CACHE] {len(QUIZ_QUESTIONS)} questions "
            f"loaded for quiz {ACTIVE_QUIZ_ID}."
        )

    return bool(QUIZ_QUESTIONS)


async def send_question_dict(link, question):
    """Send one QUESTION packet (from the cache) to a link."""

    question_number = int(question["question_number"])
    question_id = f"Q{question_number:02d}"

    packet = {
        "type": "QUESTION",
        "session_id": ACTIVE_SESSION_ID,
        "quiz_id": ACTIVE_QUIZ_ID,
        "question_id": question_id,
        "number": question_number,
        "total": len(QUIZ_QUESTIONS),
        "question": question["question_text"],
        "A": question["option_a"],
        "B": question["option_b"],
        "C": question["option_c"],
        "D": question["option_d"],
    }

    try:
        await write_json(link.client, QUESTION_CHAR_UUID, packet)

        link.last_pushed = question_number

        print(f"[QUESTION TX] {link.address} <- {question_id}")

        return True

    except Exception as e:
        print(
            f"[ERROR] Question push to {link.address} failed: {e}"
        )

        return False


async def push_next_question(link, after_number):
    """
    Push the question right after `after_number` to ONE link
    (self-paced advancing). Returns False when this student
    has reached the last question.
    """

    if not await ensure_questions_cache():
        return False

    for question in QUIZ_QUESTIONS:
        number = question.get("question_number")

        if number is not None and number > after_number:
            print(
                f"[AUTO] {link.address} advancing to "
                f"question {number}..."
            )

            return await send_question_dict(link, question)

    print(f"[AUTO] {link.address}: no more questions.")

    return False


async def resync_link_question(link):
    """
    After a (re)connect mid-quiz, push the question the
    device's student should be on, based on what they have
    already answered in the backend:
        answered Qn -> push Q(n+1); no answers -> push Q1.
    """

    if ACTIVE_QUIZ_STATUS != "running":
        return False

    if not await ensure_questions_cache():
        return False

    after_number = 0

    if link.student_id:
        success, result = await asyncio.to_thread(
            http_get_json_quiet,
            f"{FASTAPI_URL}/api/quizzes/{ACTIVE_QUIZ_ID}/students",
        )

        if success and isinstance(result, dict):
            for student in result.get("students", []):
                if (
                    str(student.get("student_id", ""))
                    == link.student_id
                ):
                    after_number = int(
                        student.get("last_answered_question") or 0
                    )
                    break

    return await push_next_question(link, after_number)


# ============================================================
# QUIZ INFO / QUIZ END BROADCAST
# ============================================================

async def send_quiz_info(link):
    """Tell one device which quiz is active."""

    await ensure_questions_cache()

    packet = {
        "type": "QUIZ_INFO",
        "quiz_id": ACTIVE_QUIZ_ID,
        "title": ACTIVE_QUIZ_TITLE,
        "status": ACTIVE_QUIZ_STATUS,
        "time_limit": ACTIVE_QUIZ_TIME_LIMIT,
        "total": len(QUIZ_QUESTIONS),
        "expected": ACTIVE_QUIZ_EXPECTED,
        "prefix": ACTIVE_QUIZ_PREFIX,
        "id_length": ACTIVE_QUIZ_ID_LENGTH,
    }

    try:
        await write_json(link.client, ACK_CHAR_UUID, packet)

        print(f"[INFO] QUIZ_INFO sent to {link.address}.")

        return True

    except Exception as e:
        print(f"[ERROR] QUIZ_INFO to {link.address} failed: {e}")

        return False


async def broadcast_quiz_info():
    for link in connected_links():
        await send_quiz_info(link)


async def send_quiz_end(link):
    packet = {
        "type": "QUIZ_END",
        "quiz_id": ACTIVE_QUIZ_ID,
    }

    try:
        await write_json(link.client, ACK_CHAR_UUID, packet)

        print(f"[INFO] QUIZ_END sent to {link.address}.")

        return True

    except Exception as e:
        print(f"[ERROR] QUIZ_END to {link.address} failed: {e}")

        return False


async def broadcast_quiz_end():
    global QUIZ_END_SENT_QUIZ

    for link in connected_links():
        await send_quiz_end(link)

    if ACTIVE_QUIZ_ID is not None:
        QUIZ_END_SENT_QUIZ = ACTIVE_QUIZ_ID


# ============================================================
# REGISTRATION PROCESS
# ESP32 -> Raspberry Pi -> FastAPI
# ============================================================

async def process_registration(link, message):
    print(f"[REGISTRATION RECEIVED from {link.address}] {message}")

    if not refresh_active_quiz():
        await send_register_ack(link, "", "REJECTED", "NO_ACTIVE_QUIZ")
        return

    try:
        packet = json.loads(message)
    except json.JSONDecodeError as e:
        print(f"[ERROR] Invalid JSON: {e}")
        await send_register_ack(link, "", "REJECTED", "INVALID_JSON")
        return

    if packet.get("type") != "REGISTER":
        await send_register_ack(
            link, packet.get("student_id", ""), "REJECTED", "INVALID_TYPE"
        )
        return

    student_id = str(packet.get("student_id", "")).strip()
    device_mac = normalize_mac(packet.get("device_mac", ""))
    device_name = str(packet.get("device_name", "")).strip()

    print(
        f"Student ID : {student_id}\n"
        f"Device MAC : {device_mac}\n"
        f"Quiz ID    : {ACTIVE_QUIZ_ID}"
    )

    if not student_id:
        await send_register_ack(link, "", "REJECTED", "EMPTY_STUDENT_ID")
        return

    if not device_mac:
        await send_register_ack(link, student_id, "REJECTED", "EMPTY_DEVICE_MAC")
        return

    success, result = register_device_with_fastapi(
        student_id=student_id,
        device_mac=device_mac,
        device_name=device_name,
        quiz_id=ACTIVE_QUIZ_ID,
    )

    if not success:
        reason = "SERVER_REGISTRATION_FAILED"

        if isinstance(result, dict):
            detail = result.get("detail") or result.get("message")
            if detail:
                reason = detail if isinstance(detail, str) else str(detail)

        await send_register_ack(link, student_id, "REJECTED", reason)
        return

    registered_devices[student_id] = {
        "device_mac": device_mac,
        "device_name": device_name,
        "quiz_id": ACTIVE_QUIZ_ID,
        "link": link,
    }

    link.student_id = student_id

    # A student registering while the quiz already runs gets
    # the question they should be on right away.
    if ACTIVE_QUIZ_STATUS == "running":
        await resync_link_question(link)

    await send_register_ack(link, student_id, "ACCEPTED")


# ============================================================
# ANSWER PROCESS
# ESP32 -> Raspberry Pi -> FastAPI
# ============================================================

async def process_answer(link, message):
    print(f"[ANSWER RECEIVED from {link.address}] {message}")

    try:
        packet = json.loads(message)
    except json.JSONDecodeError as e:
        print(f"[ERROR] Invalid JSON: {e}")
        await send_answer_ack(link, "", "REJECTED", "INVALID_JSON")
        return

    if packet.get("type") != "ANSWER":
        await send_answer_ack(
            link, str(packet.get("question_id", "")), "REJECTED", "INVALID_TYPE"
        )
        return

    if ACTIVE_QUIZ_ID is None:
        refresh_active_quiz()

    if ACTIVE_QUIZ_ID is None:
        await send_answer_ack(
            link, str(packet.get("question_id", "")), "REJECTED", "NO_ACTIVE_QUIZ"
        )
        return

    student_id = str(packet.get("student_id", "")).strip()
    question_id = str(packet.get("question_id", "")).strip().upper()
    answer = str(packet.get("answer", "")).strip().upper()

    if not student_id:
        await send_answer_ack(link, question_id, "REJECTED", "EMPTY_STUDENT_ID")
        return

    if not question_id:
        await send_answer_ack(link, question_id, "REJECTED", "EMPTY_QUESTION_ID")
        return

    if answer not in ("A", "B", "C", "D"):
        await send_answer_ack(link, question_id, "REJECTED", "INVALID_ANSWER")
        return

    # The device may have restarted or the gateway may have
    # restarted — reload registrations from the database.
    if student_id not in registered_devices:
        reload_registered_devices_from_backend(ACTIVE_QUIZ_ID)

    if student_id not in registered_devices:
        await send_answer_ack(
            link, question_id, "REJECTED", "STUDENT_NOT_REGISTERED"
        )
        return

    device_info = registered_devices[student_id]

    device_mac = normalize_mac(device_info["device_mac"])

    if device_info.get("quiz_id") != ACTIVE_QUIZ_ID:
        await send_answer_ack(
            link, question_id, "REJECTED", "QUIZ_REGISTRATION_MISMATCH"
        )
        return

    print(
        f"Student ID : {student_id}\n"
        f"Device MAC : {device_mac}\n"
        f"Quiz ID    : {ACTIVE_QUIZ_ID}\n"
        f"Question   : {question_id}\n"
        f"Answer     : {answer}"
    )

    # Sequence: the device's rising attempt counter. Older
    # firmware without it falls back to the question number
    # (last-write-wins on the backend).
    sequence = packet.get("sequence")

    if sequence is None:
        try:
            sequence = int(str(question_id).replace("Q", ""))
        except ValueError:
            sequence = None

    success, result = submit_answer_to_fastapi(
        student_id=student_id,
        device_mac=device_mac,
        question_id=question_id,
        answer=answer,
        quiz_id=ACTIVE_QUIZ_ID,
        sequence=sequence,
    )

    if not success:
        reason = "SERVER_ANSWER_FAILED"

        if isinstance(result, dict):
            detail = result.get("detail") or result.get("status")
            if detail:
                reason = detail if isinstance(detail, str) else str(detail)

        await send_answer_ack(link, question_id, "REJECTED", reason)
        return

    is_correct = bool(result.get("correct", False))

    # ACCEPTED even for DUPLICATE/STALE_IGNORED results: the
    # stored answer is authoritative and the device just needs
    # its confirmation (e.g. after a lost ACK).
    await send_answer_ack(
        link,
        question_id,
        "ACCEPTED",
        correct=is_correct,
    )

    # ------------------------------------------------
    # SELF-PACED ADVANCE: push this student's next
    # question right after the answer is accepted.
    # ------------------------------------------------

    try:
        answered_number = int(str(question_id).replace("Q", ""))
    except ValueError:
        answered_number = link.last_pushed or 0

    await push_next_question(link, answered_number)


# ============================================================
# PER-DEVICE CONNECTION SESSION
# ============================================================

def spawn(coro):
    """
    Run a callback task, logging instead of dying silently
    when the BLE link drops mid-exchange.
    """

    async def runner():
        try:
            await coro
        except Exception as e:
            print(f"[ERROR] Callback task failed: {type(e).__name__}: {e}")

    asyncio.create_task(runner())


def make_registration_callback(link):
    def callback(characteristic, data):
        message = data.decode("utf-8", errors="replace")

        if not link.connected:
            print(f"[WARN] Packet from disconnected {link.address}, dropped.")
            return

        spawn(process_registration(link, message))

    return callback


def make_answer_callback(link):
    def callback(characteristic, data):
        message = data.decode("utf-8", errors="replace")

        if not link.connected:
            print(f"[WARN] Packet from disconnected {link.address}, dropped.")
            return

        spawn(process_answer(link, message))

    return callback


async def device_session(link):
    """
    Connect one device, subscribe, greet it, keep the link
    alive. Returns when the link drops; the supervisor
    reconnects on its next cycle.
    """

    link.connected = False

    print(f"[BLE] Connecting to {link.address}...")

    client = None

    try:
        # Serialize the connection START against the
        # supervisor's scans (BlueZ InProgress errors).
        async with ble_lock:
            client = BleakClient(
                link.address,
                timeout=BLE_CONNECT_TIMEOUT,
            )
            await client.connect()

        link.client = client
        link.connected = True

        print(f"[OK] BLE connected: {link.address}")

        services = client.services

        if services is None or services.get_characteristic(
            REGISTRATION_CHAR_UUID
        ) is None:
            print(
                f"[WARN] {link.address} does not expose the "
                "PulseNet service — disconnecting."
            )
            return

        await client.start_notify(
            REGISTRATION_CHAR_UUID,
            make_registration_callback(link),
        )

        await client.start_notify(
            ANSWER_CHAR_UUID,
            make_answer_callback(link),
        )

        # Greeting: the device turns its BLE icon on.
        await write_json(
            client,
            ACK_CHAR_UUID,
            {
                "type": "ACK",
                "status": "CONNECTED",
                "quiz_id": ACTIVE_QUIZ_ID,
                "session_id": ACTIVE_SESSION_ID,
            },
        )

        # Fresh link state for the (possibly new) quiz:
        # QUIZ_INFO first, then the right question if the
        # quiz is already running (reconnect mid-quiz).
        link.last_pushed = None

        refresh_active_quiz()

        if ACTIVE_QUIZ_ID is not None:
            await send_quiz_info(link)
            await resync_link_question(link)

        # Keep the session alive until the link drops.
        while client.is_connected:
            await asyncio.sleep(2)

        print(f"[WARN] BLE link lost: {link.address}")

    except Exception as e:
        print(
            f"[WARN] BLE session for {link.address} ended: "
            f"{type(e).__name__}: {e}"
        )

        # Pace the retries (a device that is off would
        # otherwise be hammered every supervisor cycle).
        await asyncio.sleep(RECONNECT_DELAY)

    finally:
        link.connected = False
        link.client = None

        if client is not None:
            try:
                await client.disconnect()
            except Exception:
                pass


async def supervisor_loop():
    """
    Discover PulseNet devices and keep one connection session
    running per device.
    """

    while True:
        try:
            # Discover by service UUID (works for any number
            # of devices advertising PulseNet). Serialized
            # against connect starts — see ble_lock.
            async with ble_lock:
                devices = await BleakScanner.discover(
                    service_uuids=[PULSENET_SERVICE_UUID.lower()],
                    timeout=SCAN_TIMEOUT,
                    return_adv=False,
                )

            for device in devices:
                if device.address:
                    get_or_create_link(device.address)

            # (Re)start sessions for links without a live task.
            for link in links.values():
                if link.task is None or link.task.done():
                    link.task = asyncio.create_task(device_session(link))

        except Exception as e:
            print(f"[ERROR] Supervisor loop: {type(e).__name__}: {e}")

        await asyncio.sleep(SCAN_INTERVAL)


# ============================================================
# BACKGROUND LOOP - HEARTBEAT
# Gateway -> FastAPI -> Teacher dashboard
# ============================================================

async def heartbeat_loop():
    url = f"{FASTAPI_URL}/api/gateway/heartbeat"

    while True:
        live = connected_links()

        pushed = [
            link.last_pushed
            for link in live
            if link.last_pushed is not None
        ]

        payload = {
            "connected": bool(live),
            "device_address": (
                live[0].address if live else ""
            ),
            "quiz_id": ACTIVE_QUIZ_ID,
            "registered_count": len(registered_devices),
            "last_pushed_question": max(pushed) if pushed else None,
            "devices": [link.status() for link in links.values()],
        }

        await asyncio.to_thread(http_post_json_quiet, url, payload)

        await asyncio.sleep(HEARTBEAT_INTERVAL)


# ============================================================
# BACKGROUND LOOP - QUIZ WATCH
# FastAPI -> Gateway -> every ESP32
# ============================================================

def parse_iso_utc(value):
    """'2026-10-07T19:35:18' -> POSIX seconds (UTC)."""
    if not value:
        return None

    try:
        dt = datetime.fromisoformat(str(value))
    except ValueError:
        return None

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)

    return dt.timestamp()


async def quiz_watch_loop():
    """
    Watches quiz state on the backend:
    - new quiz / start / time limit change -> broadcast QUIZ_INFO
    - quiz starts                          -> push Q1 per device
    - quiz time expires                    -> finish + QUIZ_END
    - teacher finishes on the dashboard    -> QUIZ_END

    Self-paced advancing after each answer happens in
    process_answer -> push_next_question.
    """

    global ACTIVE_QUIZ_ID
    global ACTIVE_SESSION_ID
    global ACTIVE_QUIZ_TITLE
    global ACTIVE_QUIZ_STATUS
    global ACTIVE_QUIZ_TIME_LIMIT
    global ACTIVE_QUIZ_EXPECTED
    global ACTIVE_QUIZ_PREFIX
    global ACTIVE_QUIZ_ID_LENGTH
    global QUIZ_SENT_INFO_KEY
    global QUIZ_END_SENT_QUIZ
    global QUIZ_QUESTIONS_QUIZ_ID

    quizzes_url = f"{FASTAPI_URL}/api/quizzes"

    while True:
        try:
            success, quizzes = await asyncio.to_thread(
                http_get_json_quiet,
                quizzes_url,
            )

            if not success or not isinstance(quizzes, list):
                await asyncio.sleep(QUIZ_POLL_INTERVAL)
                continue

            running = [
                quiz for quiz in quizzes
                if quiz.get("status") == "running"
            ]

            lobbies = [
                quiz for quiz in quizzes
                if quiz.get("status") == "lobby"
            ]

            drafts = [
                quiz for quiz in quizzes
                if quiz.get("status") == "draft"
            ]

            # --------------------------------------------
            # Followed quiz just FINISHED (teacher ended it
            # early, or the backend expired it): notify the
            # devices so they show the result screen.
            # --------------------------------------------

            if (
                ACTIVE_QUIZ_ID is not None
                and QUIZ_END_SENT_QUIZ != ACTIVE_QUIZ_ID
            ):
                followed = next(
                    (
                        q for q in quizzes
                        if q.get("id") == ACTIVE_QUIZ_ID
                    ),
                    None,
                )

                if (
                    followed is not None
                    and followed.get("status") == "finished"
                ):
                    print(
                        "[WATCH] Followed quiz finished — "
                        "notifying devices."
                    )

                    await broadcast_quiz_end()

            # Priority: running > lobby > newest draft.
            if running:
                running.sort(key=lambda q: q.get("id") or 0, reverse=True)
                quiz = running[0]
            elif lobbies:
                lobbies.sort(key=lambda q: q.get("id") or 0, reverse=True)
                quiz = lobbies[0]
            elif drafts:
                drafts.sort(key=lambda q: q.get("id") or 0, reverse=True)
                quiz = drafts[0]
            else:
                quiz = None

            if quiz is None:
                if ACTIVE_QUIZ_ID is not None:
                    ACTIVE_QUIZ_ID = None
                    ACTIVE_SESSION_ID = None
                    ACTIVE_QUIZ_TITLE = ""
                    ACTIVE_QUIZ_STATUS = ""
                    QUIZ_SENT_INFO_KEY = None

                await asyncio.sleep(QUIZ_POLL_INTERVAL)
                continue

            quiz_id = quiz.get("id")
            status = quiz.get("status") or ""
            title = quiz.get("title") or ""

            time_limit = (
                quiz.get("time_limit_sec")
                or QUIZ_DEFAULT_TIME_LIMIT_SEC
            )

            expected = quiz.get("expected_students") or 0
            prefix = quiz.get("id_prefix") or ""
            id_length = quiz.get("id_length") or 0

            # --------------------------------------------
            # Active quiz changed: fresh session state.
            # --------------------------------------------

            if quiz_id != ACTIVE_QUIZ_ID:
                ACTIVE_QUIZ_ID = quiz_id
                ACTIVE_SESSION_ID = f"QUIZ-{quiz_id}"
                ACTIVE_QUIZ_STATUS = status
                QUIZ_SENT_INFO_KEY = None
                QUIZ_END_SENT_QUIZ = None
                QUIZ_QUESTIONS_QUIZ_ID = None

                # Devices re-register per quiz.
                registered_devices.clear()

                for link in links.values():
                    link.student_id = None
                    link.last_pushed = None

                print(
                    f"[WATCH] Following quiz {quiz_id} "
                    f"'{title}' ({status})."
                )

            ACTIVE_QUIZ_TITLE = title
            ACTIVE_QUIZ_STATUS = status
            ACTIVE_QUIZ_TIME_LIMIT = time_limit
            ACTIVE_QUIZ_EXPECTED = expected
            ACTIVE_QUIZ_PREFIX = prefix
            ACTIVE_QUIZ_ID_LENGTH = id_length

            # --------------------------------------------
            # QUIZ_INFO whenever something changed
            # (status, time limit, question count).
            # --------------------------------------------

            await ensure_questions_cache()

            info_key = (
                ACTIVE_QUIZ_ID,
                ACTIVE_QUIZ_STATUS,
                ACTIVE_QUIZ_TIME_LIMIT,
                len(QUIZ_QUESTIONS),
            )

            if info_key != QUIZ_SENT_INFO_KEY:
                QUIZ_QUESTIONS_QUIZ_ID = None

                await ensure_questions_cache()

                await broadcast_quiz_info()

                QUIZ_SENT_INFO_KEY = info_key

            # --------------------------------------------
            # Running quiz lifecycle
            # --------------------------------------------

            if ACTIVE_QUIZ_STATUS == "running":

                started = parse_iso_utc(quiz.get("started_at"))

                deadline = (
                    started + ACTIVE_QUIZ_TIME_LIMIT
                    if started
                    else None
                )

                if deadline and time.time() >= deadline:
                    print(
                        "[WATCH] Quiz time expired — finishing quiz."
                    )

                    # The backend enforces the deadline too;
                    # whichever gets there first wins.
                    await asyncio.to_thread(
                        http_post_json_quiet,
                        f"{FASTAPI_URL}/api/quizzes/"
                        f"{ACTIVE_QUIZ_ID}/finish",
                        {},
                    )

                    if QUIZ_END_SENT_QUIZ != ACTIVE_QUIZ_ID:
                        await broadcast_quiz_end()

                    await asyncio.sleep(QUIZ_POLL_INTERVAL)
                    continue

                # Give every connected device its starting
                # point: Q1 for fresh/empty devices, or the
                # question after the student's last stored
                # answer (reconnect mid-quiz).
                if QUIZ_END_SENT_QUIZ != ACTIVE_QUIZ_ID:
                    for link in connected_links():
                        if link.last_pushed is None:
                            await resync_link_question(link)

        except Exception as e:
            print(f"[ERROR] Quiz watch loop: {type(e).__name__}: {e}")

        await asyncio.sleep(QUIZ_POLL_INTERVAL)


# ============================================================
# STATUS PRINTOUTS (menu)
# ============================================================

def show_links():
    print("\n======================================")
    print("[DEVICE LINKS]")
    print("======================================")

    if not links:
        print("No devices discovered yet.")

    for link in links.values():
        state = "CONNECTED" if link.connected else "waiting"

        print(
            f"{link.address}  {state:<10}  "
            f"student={link.student_id or '-'}  "
            f"last_pushed={link.last_pushed}"
        )

    print("======================================")


def show_registered_devices():
    print("\n======================================")
    print("[REGISTERED DEVICES]")
    print("======================================")

    if not registered_devices:
        print("No devices registered.")
        return

    for student_id, info in registered_devices.items():
        print(
            f"Student ID : {student_id}\n"
            f"Device MAC : {info['device_mac']}\n"
            f"Quiz ID    : {info['quiz_id']}\n"
            "--------------------------------------"
        )


def show_active_quiz():
    print("\n======================================")
    print("[ACTIVE QUIZ]")
    print("======================================")

    if ACTIVE_QUIZ_ID is None:
        print("No active quiz.")
    else:
        print(
            f"Quiz ID : {ACTIVE_QUIZ_ID}\n"
            f"Title   : {ACTIVE_QUIZ_TITLE}\n"
            f"Status  : {ACTIVE_QUIZ_STATUS}"
        )

    print("======================================")


# ============================================================
# MENU (interactive mode only)
# ============================================================

async def menu_loop():
    while True:
        print("\n======================================")
        print("       PulseNet BLE Gateway")
        print("======================================")
        print("1. Refresh active quiz")
        print("2. Show active quiz")
        print("3. Show device links")
        print("4. Show registered devices")
        print("5. Exit")
        print("======================================")

        choice = (await asyncio.to_thread(input, "Select option: ")).strip()

        if choice == "1":
            refresh_active_quiz()
        elif choice == "2":
            show_active_quiz()
        elif choice == "3":
            show_links()
        elif choice == "4":
            show_registered_devices()
        elif choice == "5":
            print("[INFO] Exiting gateway...")
            return
        else:
            print("[ERROR] Invalid option.")

        await asyncio.sleep(0.2)


# ============================================================
# MAIN
# ============================================================

async def main():
    print("======================================")
    print("       PulseNet BLE Gateway")
    print("======================================")
    print(f"FastAPI      : {FASTAPI_URL}")
    print(f"Service UUID : {PULSENET_SERVICE_UUID}")
    print(f"Seeded device: {DEVICE_ADDRESS}")
    print("======================================")

    asyncio.create_task(heartbeat_loop())
    asyncio.create_task(quiz_watch_loop())
    asyncio.create_task(supervisor_loop())

    if INTERACTIVE:
        await menu_loop()
    else:
        print(
            "[INFO] Headless mode — devices are discovered and "
            "served automatically. Ctrl+C to stop."
        )

        while True:
            await asyncio.sleep(3600)


if __name__ == "__main__":
    try:
        asyncio.run(main())

    except KeyboardInterrupt:
        print("\n======================================")
        print("[INFO] Gateway stopped by user.")
        print("======================================")
