from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.device import Device
from app.models.quiz import Quiz
from app.models.quiz_registration import QuizRegistration
from app.models.student import Student
from app.schemas.device import (
    DeviceRegisterRequest,
    DeviceRegisterResponse,
)


router = APIRouter(
    prefix="/api/devices",
    tags=["Devices"],
)


@router.post(
    "/register",
    response_model=DeviceRegisterResponse,
)
def register_device(
    data: DeviceRegisterRequest,
    db: Session = Depends(get_db),
):
    # --------------------------------------------------------
    # 1. Check quiz
    # --------------------------------------------------------

    quiz = (
        db.query(Quiz)
        .filter(
            Quiz.id == data.quiz_id
        )
        .first()
    )

    if quiz is None:
        raise HTTPException(
            status_code=404,
            detail="Quiz not found",
        )

    # Students register while the quiz is still draft
    # (before the teacher starts it), during the lobby
    # (Kahoot-style entry window), or late while running.

    if quiz.status not in ("draft", "lobby", "running"):
        raise HTTPException(
            status_code=400,
            detail=(
                "Quiz is not open for registration "
                f"(status: {quiz.status})"
            ),
        )

    # --------------------------------------------------------
    # 2. Find or create student
    # --------------------------------------------------------

    student = (
        db.query(Student)
        .filter(
            Student.student_id == data.student_id
        )
        .first()
    )

    if student is None:
        student = Student(
            student_id=data.student_id,
        )

        db.add(student)
        db.flush()

    # --------------------------------------------------------
    # 3. Resolve the device code (display label)
    #
    # The MAC is the device IDENTITY; the code is only a
    # label shown on the dashboard. A fleet flashed with
    # identical firmware reports the SAME code from every
    # board, which would crash on the devices.device_code
    # UNIQUE constraint (or block the student behind a 400).
    # Resolve collisions by deriving a code from the MAC
    # instead — never reject a registration over a label.
    # --------------------------------------------------------

    def mac_derived_code(mac: str) -> str:
        suffix = mac.replace(":", "").upper()[-4:]
        return f"PULSENET-{suffix}" if suffix else mac

    device_code = data.device_code

    if device_code is not None:

        other = (
            db.query(Device)
            .filter(
                Device.device_code == device_code
            )
            .first()
        )

        if (
            other is not None
            and other.device_mac.upper()
            != data.device_mac.upper()
        ):
            device_code = mac_derived_code(data.device_mac)

            # The derived code must not itself collide with a
            # manually assigned label — the full MAC is
            # guaranteed unique (devices.device_mac UNIQUE).
            other = (
                db.query(Device)
                .filter(
                    Device.device_code == device_code
                )
                .first()
            )

            if (
                other is not None
                and other.device_mac.upper()
                != data.device_mac.upper()
            ):
                device_code = data.device_mac

    # --------------------------------------------------------
    # 4. Find device by MAC
    # --------------------------------------------------------

    device = (
        db.query(Device)
        .filter(
            Device.device_mac == data.device_mac
        )
        .first()
    )

    if device is None:

        device = Device(
            device_mac=data.device_mac,
            device_code=device_code,
            status="online",
            last_seen=datetime.utcnow(),
        )

        db.add(device)
        db.flush()

    else:

        # Device already exists.
        # It is NOT permanently associated with a student.

        device.status = "online"
        device.last_seen = datetime.utcnow()

        if device_code is not None:
            device.device_code = device_code

    # --------------------------------------------------------
    # 5. Check existing registration
    # --------------------------------------------------------

    registration = (
        db.query(QuizRegistration)
        .filter(
            QuizRegistration.quiz_id
            == data.quiz_id,
            QuizRegistration.device_id
            == device.id,
        )
        .first()
    )

    # --------------------------------------------------------
    # 6. Device already registered in this quiz
    # --------------------------------------------------------

    if registration is not None:

        existing_student = (
            db.query(Student)
            .filter(
                Student.id
                == registration.student_id
            )
            .first()
        )

        if (
            existing_student is not None
            and existing_student.id
            == student.id
        ):
            return DeviceRegisterResponse(
                success=True,
                message=(
                    "Device already registered "
                    "to this student for this quiz"
                ),
                student_id=student.student_id,
                device_mac=device.device_mac,
                device_code=device.device_code,
                quiz_id=data.quiz_id,
            )

        raise HTTPException(
            status_code=400,
            detail=(
                "Device is already registered "
                "to another student in this quiz"
            ),
        )

    # --------------------------------------------------------
    # 7. Check whether student already uses another device
    # --------------------------------------------------------

    student_registration = (
        db.query(QuizRegistration)
        .filter(
            QuizRegistration.quiz_id
            == data.quiz_id,
            QuizRegistration.student_id
            == student.id,
        )
        .first()
    )

    if student_registration is not None:

        raise HTTPException(
            status_code=400,
            detail=(
                "Student is already registered "
                "to another device in this quiz"
            ),
        )

    # --------------------------------------------------------
    # 8. Create quiz-scoped registration
    # --------------------------------------------------------

    registration = QuizRegistration(
        quiz_id=data.quiz_id,
        device_id=device.id,
        student_id=student.id,
        registered_at=datetime.utcnow(),
    )

    db.add(registration)

    db.commit()

    db.refresh(device)
    db.refresh(registration)

    # --------------------------------------------------------
    # 9. Return success
    # --------------------------------------------------------

    return DeviceRegisterResponse(
        success=True,
        message="Device registered successfully",
        student_id=student.student_id,
        device_mac=device.device_mac,
        device_code=device.device_code,
        quiz_id=data.quiz_id,
    )
